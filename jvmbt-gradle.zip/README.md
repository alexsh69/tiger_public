#Gradle based JAVA example project 
### This project contains explanation and examples of how to build  **```JAVA FAT JAR```**

The major goal is to provide basic rules, to be applied in the project and allow the JVMBT to assemble 
the FAT JAR and deploy it to the target

### _Project structure_:
~~~text
├── project/
    └── gradle/
    └── src/
    └── build.gradle
    └── gradlew
    └── settings.gradle
~~~

### _build.gradle_:
_the following definitions is required for fat jar assembling_
*   define `Main-Class` in `MANIFEST`:
```text
jar {
    manifest {
        attributes(
                'Main-Class': 'JvmbtGradle',
        )
    }
}
```
---  
*   define project dependencies:
```text
dependencies {
    compile(
            ['org.apache.logging.log4j:log4j-api:2.7'],
            ['org.apache.logging.log4j:log4j-core:2.7'],
            ['org.apache.logging.log4j:log4j-slf4j-impl:2.7']
    )
}
```
---
*   `task fatJar` - task to build `FAT JAR`. **DON'T CHANGE IT!**
*   `manifest.from jar.manifest` - `MANIFEST` file definition
*   `classifier` - `FAT JAR` name suffix. **DON'T CHANGE IT!**
*   `baseName` - `FAT JAR` name. **DON'T CHANGE IT!**
*   `version` - `FAT JAR` version. **DON'T CHANGE IT!**
```text
task fatJar(type: Jar) {
    manifest.from jar.manifest
    classifier = jvmbtInternalClassifier
    baseName = jvmbtInternalName
	version = jvmbtInternalVersion
    from {
        configurations.runtimeClasspath.collect { it.isDirectory() ? it : zipTree(it) }
    } {
        exclude "META-INF/*.SF"
        exclude "META-INF/*.DSA"
        exclude "META-INF/*.RSA"
        exclude "META-INF/NOTICE"
        exclude "META-INF/LICENSE"
    }
    with jar
}
```
---

##   FAT JAR Assembling:
```text
export JAVA_HOME=path-to-jdk8+
gradle -b {repository_root}\\build.gradle -PjvmbtInternalClassifier=full -PjvmbtInternalName=internal -PjvmbtInternalVersion=1.0 fatJar
output: <project_root_folder>\build\libs\<baseName>-<artifact_version>-<classifier>.jar
out jar name example: fatJar-1.0-full.jar
```
---
##  FAT JAR Structure:
*   The result `FAT JAR` contain fully populated classes from declared dependencies 
~~~text
├── dependency_packages/
    └── ...
├── dependency_packages/
    └── ...
├── project_packages/
    └── ...
├── META-INF/
    └── MANIFEST
        └── Main-Class: class_name
~~~