import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class JvmbtGradle {
    private static Logger logger = LoggerFactory.getLogger(JvmbtGradle.class);

    public static void main(String [] args)
    {
        logger.info("Info log message");
    }
}
