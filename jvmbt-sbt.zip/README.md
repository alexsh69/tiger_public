#SBT based Scala example project 
### This project contains explanation and examples of how to build  **```Scala FAT JAR```**

The major goal is to provide basic rules, to be applied in the project and allow the `JVMBT` to assemble 
the `FAT JAR` and deploy it to the target

### _Project structure_:
~~~text
├── project/
    └── assembly.sbt
├── src/
├── build.sbt
~~~

### _assembly.sbt_:
*   the following plugin is required for `FAT JAR` assembling
```text
addSbtPlugin("com.eed3si9n" % "sbt-assembly" % "0.14.6")
```

### _build.sbt_
*   `libraryDependencies`: declare project dependencies
*   `assemblyOutputPath`: `FAT JAR` output location. **DON'T CHANGE IT!**
```javascript
libraryDependencies ++= Seq(
  "org.slf4j" % "slf4j-api" % "1.7.9",
  "org.slf4j" % "slf4j-simple" % "1.7.9"
)

assemblyOutputPath in assembly := file(Option(System.getProperty("outputFile")).get)
```
---
##   FAT JAR Assembling:
```text
cd <project_root_folder>
sbt -DoutputFile=<path/fat_jar_name.jar> assembly
```
---
##  FAT JAR Structure:
*   The result `FAT JAR` contain fully populated classes from declared dependencies 
~~~text
├── scala/
├── dependency_packages/
    └── ...
├── dependency_packages/
    └── ...
├── project_packages/
    └── ...
├── META-INF/
    └── MANIFEST
        └── Main-Class: class_name
~~~