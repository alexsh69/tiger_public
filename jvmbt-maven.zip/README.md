#Gradle based JAVA example project 
### This project contains explanation and examples of how to build  **```JAVA FAT JAR```**

The major goal is to provide basic rules, to be applied in the project and allow the JVMBT to assemble 
the FAT JAR and deploy it to the target

### _Project structure_:
~~~text
├── project/
    └── src/
    └── pom.xml
~~~

### _pom.xml_:
_the following definitions is required for fat jar assembling_
---  
*   define project dependencies:
```xml
    <dependencies>
        <dependency>
            <groupId>org.apache.logging.log4j</groupId>
            <artifactId>log4j-api</artifactId>
            <version>2.7</version>
        </dependency>
        <dependency>
            <groupId>org.apache.logging.log4j</groupId>
            <artifactId>log4j-core</artifactId>
            <version>2.7</version>
        </dependency>
        <dependency>
            <groupId>org.apache.logging.log4j</groupId>
            <artifactId>log4j-slf4j-impl</artifactId>
            <version>2.7</version>
        </dependency>
    </dependencies>
```
---
*   define `Maven` plugins with rules to create `FAT JAR`. **DON'T CHANGE IT!**
*   `finalName` - define `FAT JAR` final name. **CHANGE IT**
*   `mainClass` - define `Main-Class` in `MANIFEST` file. **CHANGE IT**
```xml
    <build>
        <finalName>java-maven-10.0</finalName>
        <plugins>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-dependency-plugin</artifactId>
                <executions>
                    <execution>
                        <id>copy-dependencies</id>
                        <phase>prepare-package</phase>
                        <goals>
                            <goal>copy-dependencies</goal>
                        </goals>
                        <configuration>
                            <outputDirectory>${project.build.directory}/classes/lib</outputDirectory>
                            <overWriteReleases>false</overWriteReleases>
                            <overWriteSnapshots>false</overWriteSnapshots>
                            <overWriteIfNewer>true</overWriteIfNewer>
                        </configuration>
                    </execution>
                </executions>
            </plugin>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-jar-plugin</artifactId>
                <configuration>
                    <archive>
                        <manifest>
                            <addClasspath>true</addClasspath>
                            <classpathPrefix>lib/</classpathPrefix>
                            <mainClass>JvmbtMaven</mainClass>
                        </manifest>
                    </archive>
                </configuration>
            </plugin>
        </plugins>
    </build>
```
---

##   FAT JAR Assembling:
```text
export JAVA_HOME=path-to-jdk8+
mvn clean package -f <project_root_folder>/pom.xml -Dproject.build.directory=<project_root_folder>
out: <project_root_folder>/target/artifactId-version.jar
```
---
##  FAT JAR Structure:
*   The result `FAT JAR` contain fully populated project classes and include all of the dependency jars
*   The `MANIFEST` file contain `Class-Path` definition to provide access to included dependency jars
~~~text
├── project_packages/
    └── ...
├── lib/
    └── depndency.jar
    └── ...
├── META-INF/
    └── MANIFEST
        └── Class-Path: lib/dependency.jar lib/dependency.jar ...
        └── Main-Class: main_class
~~~