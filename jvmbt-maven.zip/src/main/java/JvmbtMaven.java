import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class JvmbtMaven {

    private static Logger logger = LoggerFactory.getLogger(JvmbtMaven.class);

    public static void main(String [] args)
    {
        logger.info("Info log message");
    }
}
